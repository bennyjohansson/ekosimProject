#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <exception>
#include <stdexcept>

//#include "consumer.h"
#include "functions.h"
#include "company_list.h"
//#include "element_company.h"
#include "error_no_return.h"

using namespace std;

Company_list::Company_list() :
  list_(0),
  size_(0),
  name_("")
{}

Company_list::Company_list(string name) :
  list_(0),
  size_(0), 
  name_(name)
{}

void Company_list::info() {
  cout << endl << "COMPANIES" << endl << "----------------------------------------------------------" << endl; 
  cout << "Number of companies: " << size_ << endl << endl;
}


int Company_list::get_size() {
  return size_;
}

void Company_list::add_company(Company * company) {
  Element_company * p;
  size_++;
  
  if(list_) {
    list_ = new Element_company(list_, company);
  }
  else {
    list_ = new Element_company(0, company);
  }
}

void Company_list::print_list() {
  
  info();
  if(list_) {
    for (Element_company *p = list_; p; p = p -> next_) {
      p->company_->info();
    }
  }
  
  cout << endl; 
}

void Company_list::print_employees(string company) {
  get_company(company) -> print_employees();
}

Element_company * Company_list::get_random_company() {
  //print_list();
  int nr = (rand()%(size_ + 1));//SKA NOG VA +1
  //cout << "I element company ransdom" << nr << endl;
  Element_company * p = list_;
  for(int i = 1; i < nr; i++) {
    //cout << i << " ";
    p = p -> next_;
  }
  return p;
}


Company * Company_list::get_company(string name) {
  Element_company * p;
  
  if(list_) {
    for(p = list_; p; p = p -> next_) {
      if (p ->get_name() == name) {
	return p -> get_company() ;
      }
    }
    throw no_return_error("Cant find the company");
  }
  else {
    throw no_return_error("no list"); 
  } 
}

double Company_list::get_capital_sum() {
  Element_company * p;
  double sum = 0;

  for (p = list_; p; p = p -> next_) {
    sum += p -> get_company() -> get_capital();
  }
  return sum;
}

double Company_list::get_item_sum() {
  Element_company * p;
  double sum = 0;

  for (p = list_; p; p = p -> next_) {
    sum += p -> get_company() -> get_stock();
  }
  return sum;
}

double Company_list::get_capacity_sum() {
  Element_company * p;
  double sum = 0;

  for (p = list_; p; p = p -> next_) {
    sum += p -> get_company() -> get_capacity();
  }
  return sum;
}



void Company_list::add_employee(string name, Consumer * consumer) {  
  get_company(name) -> add_employee(consumer);
}

void Company_list::update_company_employees() {
  double motivation_limit =  0.3;
  double skill_limit = 0.5;

  Element_company * p;
  
//  for(p = list_; p -> next_; p = p -> next_) {
//    cout << "I coom list upd comp empl1" << endl;
//    (p -> get_company()) -> update_employees(skill_limit, 
//					     motivation_limit);
//  }
}

void Company_list::employee_info(string command) {
  Element_company * q;
  cout << endl << name_ << endl << "--------------------------------" << endl;
  if(command == "all" || command == "") {
    for(q = list_; q; q = q -> next_) {
      q -> get_company() -> employee_info();
    }
  }
  else {
    try {
      get_company(command) -> employee_info();
    } 
    catch(no_return_error) {
      cout << "Company not found" << endl;
    }
    //    catch(exception& e) {
    //  cout << typeid(e) .name() << ": " << e.what() << endl;
    //}
  }
}

void Company_list::produce() {
  
  Element_company * p;
  
  for(p = list_; p; p = p -> next_) {
    (p -> get_company()) -> produce();
  }
}

void Company_list::pay_employees() {

  Element_company * p;

  for(p = list_; p; p = p -> next_) {
    (p -> get_company()) -> pay_employees();
  }
}

double Company_list::pay_dividends() {

  Element_company * p;
  double total_profit = 0;
  
  total_profit = get_capital_sum();

  if(total_profit > 0) {
    for(p = list_; p; p = p -> next_) {
      (p -> get_company()) -> set_capital(0);
    }
  }
  else {
    total_profit = 0;
  }

  return total_profit;
}


void Company_list::sell_to_market() {
  
  Element_company * p;
  
  for(p = list_; p; p = p -> next_) {
    (p -> get_company()) -> sell_to_market();
      }
}

void Company_list::remove_usless_employees() {
  
  Element_company * p;
  //  cout << "I company_list" << endl;
  if(list_) {  
    for(p = list_; p; p = p -> next_) {
      //  cout << "I company_list" << endl;
      (p -> get_company()) -> remove_usless_employees();
    }
  }
  else {
    cout << "No companies in company list" << endl;
  }
  // cout << "I company list usless" << endl;
}
  

//Borde kunna gora nat smartare, dar man anropar listan med
//en funktion och att den gor pa hela listan...
//Nu blev det har daligt. company maste kanna till arb markn
//annars blir det ett javla massa skickande. Det har maste andras.

bool Company_list::update_employees(Consumer * opt, string name) {
  if(name == "all") {
    return update_employees(opt);
  }
  else { 
    return get_company(name) -> update_employees(opt);
  }
}

bool Company_list::update_employees(Consumer * opt) {
  Element_company * p;
  
  for(p = list_; p; p = p -> next_) {
    cout << "vi loopar i com list upd emp" << endl;
    return p -> get_company() -> update_employees(opt);
  }
}


bool Company_list::update_employees2(Consumer * opt) {
  Element_company * p = get_random_company();
  Element_company * r = p;
  Element_company * q;
  bool after = 0;
  bool before = 0;
  //  cout << "I com list upd empl 2 hittar vi n�t random company?" << endl;
  //Checks the random company and the ones after in the list
  //cout << endl << "Company list upd empl" << endl << p -> get_name() << endl;
  //opt -> info();
  
  for(p; p; p = p -> next_) {
    after = p -> get_company() -> update_employees(opt);
    
    //If employed, return true and get a new opt consumer
    if(after) {
      //      opt -> set_employment_status(true);
      return after;
    }
  }
  //Checks the list from the start and till the random
  for(q = list_; q != r; q = q -> next_) {
    
    before = q -> get_company() -> update_employees(opt);
    
    //If employed, return true and get a new opt consumer
    if(before) {
      //opt -> set_employment_status(true);
      return before;
    }
  }
  //No one wants to hire opt, done. 
  return false;
}


void Company_list::invest() {
  Element_company * p;
  
  for(p = list_; p; p = p -> next_) {
    p -> get_company() -> invest();
  }
}









