#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <list>

//#include "consumer.h"
#include "company.h"
#include "functions.h"
#include "error_no_return.h"

using namespace std;

Company::Company() :
  name_(""),
  capital_(0),
  stock_(0),
  invest_(0.6),
  prod_const_skill_(60),
  prod_const_motivation_(40),
  wage_const_(0.9),
  market_(0),
  employees_(new Consumer_list("Employees")){}

Company::Company(string name, Market * market, Clock * clock) :
  name_(name),
  capital_(10000),
  stock_(0),
  invest_(0.6),
  prod_const_skill_(60),
  prod_const_motivation_(40),
  wage_const_(0.9),
  market_(market),
  capacity_(400),
  clock_(clock),
  employees_(new Consumer_list("Employees"))
{}


void Company::info() {
  
  cout << "Name: " << name_ << endl 
       << "Capital: " <<  capital_ << endl
       << "Stock: " << stock_ << endl 
       << "Employees: " << employees_ -> get_size() << endl << endl;
}

void Company::employee_info() {
  cout << name_ << endl << "---------------------" << endl;
  employees_ -> info();
}

string Company::get_name() {
  return name_;
}

double Company::get_capital() {
  return capital_;
}

double Company::get_prod_const_skill() {
  return prod_const_skill_;
}

double Company::get_prod_const_motivation() {
  return prod_const_motivation_;
}

double Company::get_wage_const() {
  return wage_const_;
}

double Company::get_production() {
  
  double skill_sum = employees_ -> get_skill_sum(); 
  double sk = prod_const_skill_;
  double mot_sum =employees_ -> get_motivation_sum();
  //  cout << "I comp get prod, mot sum: " << mot_sum << endl; 
  double mot = prod_const_motivation_;
  double employees = employees_ -> get_size();
  double prod =  get_prod(skill_sum, sk, mot_sum, mot, employees, capacity_);
  return prod;
}

double Company::get_production(Consumer * consumer) {

  //double prod = consumer -> get_skill() * prod_const_skill_ +
  //  consumer -> get_motivation() * prod_const_motivation_;
  double skill = consumer -> get_skill();
  double mot = consumer -> get_motivation();
  double prod = get_prod(skill, skill, mot, mot, 1, capacity_);

  return prod;
} 

double Company::get_stock() {
  return stock_;
}

double Company::get_invest() {
  return invest_;
}

double Company::get_capacity() {
  return capacity_;
}

void Company::set_capital(double capital) {
  capital_ = capital;
}

void Company::set_prod_const_skill(double skill) {
  prod_const_skill_ = skill;
}

void Company::set_prod_const_motivation(double mot) {
  prod_const_motivation_ = mot;
}

void Company::set_wage_const(double wc) {
  wage_const_ = wc;
}

void Company::set_stock(double stock) {
  stock_ = stock;
}

void Company::set_invest(double invest) {
  invest_ = invest;
}

void Company::set_capacity(double capacity) {
  capacity_ = capacity;
}

void Company::change_capital(double ch) {
  //  if (capital_ + ch > 0) {
  capital_ += ch;
  // }
  //else {
  //cout << "Fel i company ch cap" << endl;
  // }
}

void Company::change_prod_const_skill(double ch) {
  prod_const_skill_ += prod_const_skill_;
}

void Company::change_prod_const_motivation(double ch) {
  prod_const_motivation_ += ch;
}

void Company::change_wage_const(double wcc) {
  wage_const_ += wcc;
}

void Company::change_stock(double ch) {
  stock_ += ch;
}

void Company::change_invest(double ch) {
  invest_ += ch;
}

void Company::change_capacity(double ch) {
  capacity_ += ch;
}

void Company::add_employee(Consumer * consumer) {
  
  if(!(consumer -> get_employment_status())) {
    employees_-> add_first(consumer);
    consumer -> set_employment_status(true);
    //   cout << "I companu add consumer, nu addar vi" << endl;
  }
  else {
    throw no_return_error("Nu j�vlar n�rmar det sig");
  }
}

void Company::print_employees() {
  employees_ -> print_list();
}

void Company::produce() {  
  stock_ += get_production();
}

double Company::get_total_wages() {
  double production = 0;
  int size = 0;
  double price = 0;
  double max_factor = 0.02;
  size = employees_ -> get_size();
  
  if (size) {
    production = get_production();
    price = market_->get_price_in();
  }

  list<double>::iterator theIterator;
  theIterator = wages_.begin();
  
  //Using value of wages instead
  double wages = production * price * wage_const_ ;
  //double value_wages = production*wage_const_;
  if(clock_ -> get_time() > 70) {
    if(wages/size > *theIterator*(1+max_factor)) {
      wages = *theIterator*(1+max_factor)*size;
      //  cout << "I comp get tot wages vi begransar! uppat" << endl;
    }    
    //wages = *theIterator*size;
    if(wages/size < *theIterator*(1-max_factor)) {
      wages = *theIterator*(1-max_factor)*size;
      //      cout << "I comp get tot wages vi begransar! nerat" << endl;
    }
  }

  //  if(clock_ -> get_time() > 20) {
    //wages = *theIterator*size;
  //cout << "hej i com get tot wages" << endl;
  //}
  //if(wages/size>300) {
  //  wages = 300*size;
  //
  //}
  return wages;
}

void Company::pay_employees() {
  double size = 0;
  double wage_tot = 0;
  double wage = 0;
  double price = 0;

  //  cout << "TETS I COMOPANY WAGES" << endl;
  price = market_ -> get_price_in();
  size = employees_ -> get_size();

  wage_tot = get_total_wages();

  if (size) {
    wage = wage_tot/size;
    employees_ -> pay_employees(wage);
    double sum_after = employees_ -> get_capital_sum();
    capital_ -= wage_tot;
  }

  wages_.push_front(wage);
}


//JUST JA; WAGES HAR BLIR FEL DA VI TAR BORT EN CONSUMER
//Checks how the expected income changes by adding consumer 
double Company::contribution_adding(Consumer * consumer) {
  double skill = consumer -> get_skill();
  double mot = consumer -> get_motivation();
  double skill_sum = employees_ -> get_skill_sum();
  double mot_sum = employees_ -> get_motivation_sum();
  int employees = employees_ -> get_size();
  double sk_c = prod_const_skill_;
  double mot_c = prod_const_motivation_;

  double prod_before = get_production();
  double prod_after = get_prod(skill_sum+skill, sk_c, mot_sum+mot, mot_c, employees +1, capacity_);
  
  double price = market_ -> get_price_in();
  double wage = 0;
  double size = employees_ -> get_size() + 1;//I need to add the "1" here to get it right???

  
  if (size != 0) {
    wage = get_total_wages()/size;
  }
  else {
    wage = get_total_wages();   
  }
  
  //list<double>::iterator theIterator;
  //theIterator = wages_.begin();
  //wage = *theIterator;

  double contribution = 0;

  contribution = (prod_after - prod_before)*price - wage;
  return contribution;
}

double Company::contribution_removing(Consumer * consumer) {
  double skill = consumer -> get_skill();
  double mot = consumer -> get_motivation();
  double skill_sum = employees_ -> get_skill_sum();
  double mot_sum = employees_ -> get_motivation_sum();
  int employees = employees_ -> get_size();
  double sk_c = prod_const_skill_;
  double mot_c = prod_const_motivation_;
  double contribution = 0;

  double prod_before = get_production();
  double prod_after = get_prod(skill_sum - skill, sk_c, mot_sum - mot, 
			       mot_c, employees - 1, capacity_); 

  double price = market_ -> get_price_in();
  //double wage = wage_const_ * get_production(consumer)*price;
  
  double size = employees_ -> get_size();
  double wage = 0;


  if (size != 0) {
    wage = get_total_wages()/size;
    contribution = (prod_after - prod_before)*price + wage;
  }
  else {
    wage = get_total_wages();
    contribution = 0;
  }
  //list<double>::iterator theIterator;
  //theIterator = wages_.begin();
  //wage = *theIterator;
  //  cout << "cont rem i company, cont = " << endl 
  //     << "Contr before: " << prod_before << endl 
  //     << "Prod_after" << prod_after << endl 
  //     << "Contribution: " << contribution << endl;
  
  return contribution;
} 

void Company::remove_usless_employees() {
  try {
    Consumer * bad_empl = employees_ -> get_usless_employee(prod_const_skill_, prod_const_motivation_, capacity_);
    
    //    double contr  = contribution_removing(bad_empl);
    //cout << contr << endl;
    
    while(contribution_removing(bad_empl) > 1) {
      
      remove_employee(bad_empl);
      bad_empl = employees_ -> get_usless_employee(prod_const_skill_,  prod_const_motivation_, capacity_);
    }
  }
  catch(std:: exception b) {
    cout << b.what() << endl << "Error i company rem usless" << endl;  
  }
}




bool Company::update_employees(Consumer * opt) {
  //    cout << name_ << "  " << employees_->get_size() << endl;

  //if(employees_ -> get_size() != 0) {

  //  if (employees_ -> get_size() <= 2) {
  //   employees_ -> print_list();
  //}
  
  //  cout << name_ << "	" << employees_->get_size() << endl;  
  
  if(contribution_adding(opt) > 1) {
    try {
      add_employee(opt);
    }
    catch (std:: exception a) {
      cout << a.what() << endl;
      return false;
    }
    
    return true;
  }
  
  else {
    return false;
  }
  //}
  //else {
  //cout << "I company update empty list to add to" << endl << name_ << endl << "Adding optimal consumer: " << endl;
    
  //opt -> info();
  //cout << endl;
  //employees_ -> info();
  //add_employee(opt);
  //opt -> info();
  //employees_ -> info();
  //return true;
  //}
}

void Company::update_employees(double skill_limit, 
			       double motivation_limit) {
  //employees_ -> remove_by_motivation(motivation_limit);
  //employees_ -> remove_by_skill(skill_limit);
}

void Company::remove_employee(Consumer * consumer) {
  //consumer -> set_employment_status(false);
  consumer -> set_income(0);
  //cout << name_ << employees_ -> get_size() << endl;
  employees_ -> remove_consumer(consumer, capacity_);
  //cout << "I coma rem empl" << endl;
  //employees_ -> print_list();
}  


void Company::sell_to_market() {
  double price = market_ -> get_price_in();
  //cout << "s " << stock_ << " p " << price << endl;
  //market_ -> change_items(stock_);
  //change_capital(price*stock_);
  //  cout << "stock: " << stock_ << endl <<"i sell to market company Price: " << price << endl;
  //  if (market_ -> change_capital(-price*stock_)) {
  
  change_capital(price*stock_);
  market_ -> change_capital(-price*stock_);

  market_ -> change_items(stock_);
  change_stock(-stock_);
  //  }
  //else {
  //cout << "Kuk i company sell" << endl;
  //}
}

void Company::invest() {
  double investment = 0;
  double limit = 500000;
  if(capital_ > 0 && investment < limit) {
    investment = invest_ * capital_;
    //    capital_ -= investment;
    //Borde kunna investera bade i storlek, dvs rate, och effektivitet, dvs 
    //prod const skill och motivation. Gor ett enkelt forsok, men borde eg
    //kolla pa reapektive derivator
  }
  else if(investment > limit) {
    //investment = limit;
  }
  
  //  prod_const_motivation_ *= 1 + 0.5*investment/limit;
  //prod_const_skill_ *= 1 + 0.5*investment/limit;
    
}



















